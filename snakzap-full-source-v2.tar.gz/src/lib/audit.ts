import { createHash } from 'crypto'
import { db } from './db'

// P0-22 — Audit trail integrity (immutable, complete)
// Direct Protector of I-07 (Audit Integrity).
//
// DEV-001 CLOSURE: Hash-chain tamper-evidence implemented.
// Each audit entry includes: prevHash (hash of previous entry) + hash (SHA-256 of own data).
// If any entry is modified or deleted, the chain breaks and integrity check detects it.
//
// This makes tampering DETECTABLE. True PREVENTION (blocking UPDATE/DELETE at storage level)
// still requires production-grade WORM storage (PostgreSQL REVOKE, QLDB, or separate audit DB).
// The hash-chain is the interim tamper-EVIDENCE layer; production WORM is the tamper-PREVENTION layer.

function computeHash(
  prevHash: string,
  id: string,
  actorId: string | null,
  actorRole: string,
  action: string,
  metadata: string,
  createdAt: Date,
): string {
  const data = `${prevHash}|${id}|${actorId ?? 'null'}|${actorRole}|${action}|${metadata}|${createdAt.toISOString()}`
  return createHash('sha256').update(data).digest('hex')
}

// Create an audit log entry with hash-chain linkage.
// This is the ONLY sanctioned write path to the audit table.
export async function audit(
  action: string,
  metadata: Record<string, unknown> = {},
  actorId?: string,
  actorRole: string = 'SYSTEM',
): Promise<void> {
  // Get the last entry's hash (for chain linkage)
  const lastEntry = await db.auditLog.findFirst({
    orderBy: { createdAt: 'desc' },
    select: { hash: true },
  })
  const prevHash = lastEntry?.hash || 'GENESIS'

  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
  const createdAt = new Date()
  const metadataStr = JSON.stringify(metadata)
  const hash = computeHash(prevHash, id, actorId ?? null, actorRole, action, metadataStr, createdAt)

  await db.auditLog.create({
    data: {
      id,
      actorId: actorId ?? null,
      actorRole,
      action,
      metadata: metadataStr,
      createdAt,
      prevHash,
      hash,
    },
  })
}

// Read audit logs (paginated, filterable) — READ ONLY.
export async function readAuditLogs(opts: {
  limit?: number
  offset?: number
  action?: string
  actorId?: string
} = {}) {
  const { limit = 30, offset = 0, action, actorId } = opts
  return db.auditLog.findMany({
    where: {
      ...(action ? { action: { contains: action } } : {}),
      ...(actorId ? { actorId } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: Math.min(limit, 100),
    skip: offset,
    include: { actor: { select: { name: true, phone: true } } },
  })
}

// Integrity check: verify the hash chain is unbroken.
// Walks all entries in chronological order, recomputes each hash, and verifies:
//   1. Each entry's hash matches recomputed hash (no mutation)
//   2. Each entry's prevHash matches previous entry's hash (no deletion/insertion)
// Returns { ok, brokenCount, totalCount, firstBrokenEntry? }.
export async function auditIntegrityCheck(): Promise<{
  ok: boolean
  brokenCount: number
  totalCount: number
  firstBrokenEntry?: { id: string; action: string; issue: string }
}> {
  const entries = await db.auditLog.findMany({
    orderBy: { createdAt: 'asc' },
    select: { id: true, actorId: true, actorRole: true, action: true, metadata: true, createdAt: true, prevHash: true, hash: true },
  })

  let brokenCount = 0
  let prevHash = 'GENESIS'
  let firstBrokenEntry: { id: string; action: string; issue: string } | undefined

  for (const entry of entries) {
    // Check chain linkage
    if (entry.prevHash !== prevHash) {
      brokenCount++
      if (!firstBrokenEntry) {
        firstBrokenEntry = { id: entry.id, action: entry.action, issue: `prevHash mismatch: expected ${prevHash}, got ${entry.prevHash}` }
      }
    }

    // Check hash integrity
    const recomputedHash = computeHash(entry.prevHash, entry.id, entry.actorId, entry.actorRole, entry.action, entry.metadata, entry.createdAt)
    if (entry.hash !== recomputedHash) {
      brokenCount++
      if (!firstBrokenEntry) {
        firstBrokenEntry = { id: entry.id, action: entry.action, issue: 'hash mismatch (entry may have been modified)' }
      }
    }

    prevHash = entry.hash
  }

  return {
    ok: brokenCount === 0,
    brokenCount,
    totalCount: entries.length,
    firstBrokenEntry,
  }
}
